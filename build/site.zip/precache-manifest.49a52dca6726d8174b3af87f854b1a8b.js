self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "bfcc37369b3767af0fcf6afd96177c5a",
    "url": "/covid19/index.html"
  },
  {
    "revision": "3d62eff74860445c7071",
    "url": "/covid19/static/css/main.efd67110.chunk.css"
  },
  {
    "revision": "15929a91f68d23a9e48a",
    "url": "/covid19/static/js/2.7062a37f.chunk.js"
  },
  {
    "revision": "3453b8997016469371284a28c0e873e2",
    "url": "/covid19/static/js/2.7062a37f.chunk.js.LICENSE.txt"
  },
  {
    "revision": "3d62eff74860445c7071",
    "url": "/covid19/static/js/main.3fab5038.chunk.js"
  },
  {
    "revision": "c8b07cea672cb7434d60",
    "url": "/covid19/static/js/runtime-main.48718ead.js"
  }
]);